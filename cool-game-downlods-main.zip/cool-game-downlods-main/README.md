# cool-game-downlods
A bunch of cool game downloads that are from other repos and programs.
These games are from lax1dude, Google Chrome, paveldogreat, and Niloy Sidar.
# lax1dude
He posted two versions of eaglercraft so far. Regular eaglercraft, and Eaglercraft Beta.
The regular version has more features, and the beta is better in terms of design but it does not have local support.
# paveldogreat
He made the fluid webgl simulator which is extremely satisfying ahd fun.
# Niloy Sidar
He made the box stack game which is really fun to play.
